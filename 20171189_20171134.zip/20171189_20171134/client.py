import os
import sys
import random
import time

if len(sys.argv) < 4:
    print "Usage: python client.py <CLIENT_PORTS_RANGE> <PROXY_PORT> <END_SERVER_PORT>"
    print "Example: python client.py 20001-20099 20001-20099 20100"
    raise SystemExit

CLIENT_PORTA = sys.argv[1]
PROXY_PORT = sys.argv[2]
SERVER_PORT = sys.argv[3]

D = {0: "GET", 1: "POST"}
username = 'sravani'
password = 'hello'

while True:
    #filename = "%d.data" % (int(random.random() * 1) + 1)
    
    METHOD = D[int(random.random() * len(D))]
    CLIENT_PORT = str(random.randint(int(CLIENT_PORTA), int(CLIENT_PORTA) + 10))
    if int(PROXY_PORT) > 20099 or int(PROXY_PORT) < 20000:
        print 'proxy port not in range'

    if int(CLIENT_PORT) > 20099 or int(CLIENT_PORT) < 20000:
        print 'client port not in range'

    if int(SERVER_PORT)!=20100:
        print 'server port not in iiit servers range'

    if CLIENT_PORT == SERVER_PORT or SERVER_PORT == PROXY_PORT or PROXY_PORT == CLIENT_PORT:
        print 'check ports'
    user_det1 = username+":"+password
    l=len(user_det1)+1
    user_det2 = user_det1.rjust(l);
    l = l + 1;
    user_det = user_det2.ljust(l);
    if METHOD != "GET" and METHOD != "POST":
        print "Only Get or Post requests are possible"
        break
    os.system("curl --user"+user_det+"--request %s --proxy 127.0.0.1:%s google.com/search?source=hp&ei=TnekXOynD9a1rQGzupOQAQ&q=hey&btnK=Google+Search&oq=hey&gs_l=psy-ab.3..0l10.2378.2639..3077...0.0..0.108.364.3j1......0....1..gws-wiz.....0..0i131.6Q01w0umaVk" % (
        METHOD, PROXY_PORT))

    time.sleep(5)

    
    filename = "README.md"
    os.system("curl --user pranav:qwerty --request %s  --proxy 127.0.0.1:%s 127.0.0.1:%s/%s" % (
        METHOD, PROXY_PORT, SERVER_PORT, filename))

    time.sleep(5)