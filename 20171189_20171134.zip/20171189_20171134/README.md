This is a multithreaded HTTP proxy server, can handle many requests, using sockets.
Allows only GET or POST
Uses cache for same requests
